const { createTheme } = require("@mui/material");


const theme=createTheme({
    typography:{
        fontFamily:'-apple-system',
    }
})
export default theme